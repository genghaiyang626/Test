from tkinter import *
import tkinter as tk
win=Tk()
win.geometry('500x230')
win.title('图书库存管理系统')

monty=tk.LabelFrame(win,text="图书库存管理系统")
monty.grid(column=0,row=0,padx=10,pady=10)
# aLabel=tk.Label(monty,text="A Label")
# tk.Label(monty,text="请选择一个数字：").grid(column=1,row=0)
Button(monty,text="显示书目信息",font=('华文新魏','16')).grid(column=1,row=0)
Button(monty,text="显示库存信息",font=('华文新魏','16')).grid(column=1,row=1)
Button(monty,text="添加书目信息",font=('华文新魏','16')).grid(column=1,row=2)
Button(monty,text="退       出",font=('华文新魏','16')).grid(column=1,row=3)
# Entry(monty,textvariable="",width=16,font=('宋体','16')).grid(column=2,row=0)
win.mainloop()