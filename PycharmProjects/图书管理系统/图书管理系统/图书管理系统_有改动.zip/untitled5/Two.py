from tkinter import *
import tkinter as tk
win=Tk()
win.geometry('500x230')
win.title('图书库存管理系统')
#提交按钮事件
def mClick():
    txt=txt2.get()
    if(txt == '123'):
        txt3.set("图书添加成功")
#创建几个组件元素
monty=tk.LabelFrame(win,text="图书库存管理系统")
monty.grid(column=0,row=0,padx=10,pady=10)

lab1=Label(monty,text="书号：",font=('华文新魏','16')).grid(row=1,column=0)
lab2=Label(monty,text="书名：",font=('华文新魏','16')).grid(row=2,column=0)
lab3=Label(monty,text="出版时间：",font=('华文新魏','16')).grid(row=3,column=0)
lab4=Label(monty,text="价格：",font=('华文新魏','16')).grid(row=4,column=0)
lab5=Label(monty,text="库存：",font=('华文新魏','16')).grid(row=5,column=0)
txt1=StringVar()
txt2=StringVar()
txt3=StringVar()
txt4=StringVar()
txt5=StringVar()
txt6=StringVar()
txt6.set("添加图书信息")
entry1=Entry(monty,textvariable=txt1,width=16,font=('宋体','16')).grid(row=1,column=1)
entry2=Entry(monty,textvariable=txt2,width=16,font=('宋体','16')).grid(row=2,column=1)
entry3=Entry(monty,textvariable=txt3,width=16,font=('宋体','16')).grid(row=3,column=1)
entry4=Entry(monty,textvariable=txt4,width=16,font=('宋体','16')).grid(row=4,column=1)
entry5=Entry(monty,textvariable=txt5,width=16,font=('宋体','16')).grid(row=5,column=1)
#photo = PhotoImage(file="bg.gif")

button=Button(monty,text='提交',command=mClick,font=('宋体','16')).grid(row=6,column=2)
lab6=Label(monty,textvariable=txt6,relief='ridge',width=30,font=('华文新魏','16')).grid(row=6,column=0,columnspan=2)


#布局设置
# lab1.grid(row=0,column=0)
# lab2.grid(row=1,column=0)
# lab3.grid(row=2,column=0)
# lab4.grid(row=3,column=0)
# lab5.grid(row=4,column=0)
# entry1.grid(row=0,column=1)
# entry2.grid(row=1,column=1)
# entry3.grid(row=2,column=1)
# entry4.grid(row=3,column=1)
# entry5.grid(row=4,column=1)
# lab6.grid(row=5,column=0,columnspan=2)
# button.grid(row=5,column=2)

win.mainloop()