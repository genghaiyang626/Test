from 图书管理系统.untitled5.book.book_list_manage import *
from 图书管理系统.untitled5.book.inventory_manage import *